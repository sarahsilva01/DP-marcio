// src/components/Profile.tsx
import styles from "../styles/components/Profile.module.css";

export function Profile() {
  return (
    <div className={styles.profileContainer}>
      <img
        src="https://avatars.githubusercontent.com/u/1?v=4"
        alt="Usuário"
      />

      <div>
        <strong>Seu Nome</strong>
        <p>
          <img
            src="https://cdn-icons-png.flaticon.com/512/190/190411.png"
            alt="Level"
          />
          Level 1
        </p>
      </div>
    </div>
  );
}
