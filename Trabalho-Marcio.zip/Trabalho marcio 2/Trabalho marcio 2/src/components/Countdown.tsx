// src/components/Countdown.tsx
import { useEffect, useState } from "react";
import styles from "../styles/components/Countdown.module.css";

const INITIAL_TIME = 25 * 60; // 25 minutos

export function Countdown() {
  const [time, setTime] = useState(INITIAL_TIME);
  const [isActive, setIsActive] = useState(false);
  const [hasFinished, setHasFinished] = useState(false);

  const minutes = Math.floor(time / 60);
  const seconds = time % 60;

  const [minuteLeft, minuteRight] = String(minutes).padStart(2, "0").split("");
  const [secondLeft, secondRight] = String(seconds).padStart(2, "0").split("");

  useEffect(() => {
    let timeout: NodeJS.Timeout;

    if (isActive && time > 0) {
      timeout = setTimeout(() => {
        setTime((old) => old - 1);
      }, 1000);
    } else if (isActive && time === 0) {
      setHasFinished(true);
      setIsActive(false);
    }

    return () => clearTimeout(timeout);
  }, [isActive, time]);

  function handleStartCountdown() {
    setIsActive(true);
  }

  function handleResetCountdown() {
    setIsActive(false);
    setHasFinished(false);
    setTime(INITIAL_TIME);
  }

  return (
    <div>
      <div className={styles.countdownContainer}>
        <div>
          <span>{minuteLeft}</span>
          <span>{minuteRight}</span>
        </div>
        <span>:</span>
        <div>
          <span>{secondLeft}</span>
          <span>{secondRight}</span>
        </div>
      </div>

      {hasFinished ? (
        <button disabled className={styles.finishedButton}>
          Ciclo encerrado
        </button>
      ) : (
        <>
          {isActive ? (
            <button
              onClick={handleResetCountdown}
              className={`${styles.countdownButton} ${styles.active}`}
            >
              Abandonar ciclo
            </button>
          ) : (
            <button
              onClick={handleStartCountdown}
              className={styles.countdownButton}
            >
              Iniciar ciclo
            </button>
          )}
        </>
      )}
    </div>
  );
}
